# Health Human Capital Investment and Firm Employment in China

## Run

Use Python 3.12 and install the recorded dependencies:

```bash
python -m pip install -r requirements.txt
python code/python/run_all.py
```

The runner assembles the estimation sample from the processed data files and estimates the reported models.

## Publication mapping

| Item | Machine-readable result |
|---|---|
| Tables 1 and A4 | output/tables/table_01_descriptive.csv |
| Table 2 | output/tables/table_02_baseline_full.csv |
| Table 3 | output/tables/table_03_event_study.csv |
| Table 4 and A5–A7, A9 | output/tables/table_04_robustness_merged.csv |
| Table 5 | output/tables/table_05_mechanisms.csv |
| Table 6 and A8 | output/tables/table_06_heterogeneity.csv |
| Table 7 | output/tables/table_07_revenue.csv |
| Paired subgroup comparisons | output/tables/table_06b_subgroup_differences.csv |
| Tables A1–A3 | data/policy_and_core_definitions.csv and data/data_dictionary.csv |

Figures 1–2 and A1–A2 are in output/figures. Logs are in output/logs.
Data definitions and construction are in data/documentation/DATA_CONSTRUCTION.md.

Fixed-effects regressions use the eight baseline financial controls and absorb firm, industry and year effects as specified in each table. Standard errors cluster by city, with the alternative firm-cluster specification reported in Table 4. Stars use two-sided asymptotic normal probabilities.



## Revenue

Table 7 reports log revenue only. The series lwage is constant within city-year and is not used as firm pay.

Detailed variable definitions are in data/documentation/VARIABLE_CONSTRUCTION.md.

## Health-capital framework and employment checks

The economic question is health human capital investment and firm labour demand. Work-injury prevention entry measures access to the public preventive-investment margin.

Run code/python/health_investment_checks.py for stable-city and never-treated cohort comparisons (Appendix A10). Run code/python/check_health_framework.py for hiring and health-stock checks. Appendix A11 maps theory to measures. Outputs are table_A10* and output/logs/health_*json.

Appendix Table A12 is reproduced by code/python/pre2017_comparison.py and stored in output/tables/table_A12_window.csv.
