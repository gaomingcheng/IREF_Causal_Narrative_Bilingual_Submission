# Data construction

The core 2011–2018 panel is assembled from firm-level records in the China Stock Market and Accounting Research (CSMAR) database and the Chinese Research Data Services Platform (CNRDS), together with the 2011 observations: 17,441 company-years, 2,214 firms and 249 cities. The internal company identifier and year uniquely identify observations.

`prepare_panel.py` joins the four processed data files by company and year, preserving the core exposure and financial variables. All core rows are kept, including missing outcomes. Company links use annual headcount comparisons, requiring at least two exact matches and 80% agreement; ambiguous stock codes are excluded. Expanded financial controls use the linked records.

Three accounting workbooks are in data/raw. The workforce input is the processed workforce-structure panel in data/processed. Baseline controls use their database transformations. Employee counts are logged for the employment outcomes. Cohort-time controls are measured in the year before entry. Treatment follows formal entry of the registered city. The city-level permutation procedure preserves observed cohort city counts. Data dictionary and institutional definitions are provided as CSV files.

The estimation sample links the firm employment and financial records, formal city-entry policy records and related CSMAR/CNRDS fields.
