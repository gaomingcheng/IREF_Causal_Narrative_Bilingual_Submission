# Variable construction

B1. Annual-report risk disclosure

CNRDS’s Annual Report Keywords Research Database reports frequencies for 16 risk-related words in its risk-information-disclosure module. The analysis uses three nested dictionaries: D6 = {风险, 困境, 过剩, 债务, 危机, 负担} (risk, distress, excess capacity, debt, crisis, burden); D3 = {风险, 债务, 危机}; and D1 = {风险}. The Chinese words are the matching terms; the English expressions are translations.

Let n_it(w) denote the annual-report count of word w. The total count is F_it(D) = Σ[w∈D] n_it(w), and R_it(D) = ln F_it(D) for a positive total. The fields risk1, risk2 and risk3 correspond to D6, D3 and D1. Each index is a log count, without division by report length. The regressions use these logged fields and preserve their missing observations. Narrowing the dictionary tests whether the disclosure result depends on including broader negative language.

B2. Financial risk

The financial-risk outcome is fZscore = −Z, where Z is the source-specific accounting index Z = 1.2 ln(current assets − current liabilities) + 1.4 ln(undistributed profits + surplus reserve) + 3.3 ln(income tax expense + net profit + finance expense) + 0.6 × Tobin's Q + 0.99 ln(operating revenue). The accounting terms enter as natural logarithms of their levels, and Tobin's Q enters as a ratio. A decrease in fZscore means an increase in Z and lower measured financial distress. The measure covers 11,936 firm-years; it is undefined when a logarithm argument is non-positive, and those observations remain missing rather than imputed.

B3. Labour costs and the local benchmark

The labour-risk-premium concept compares the firm’s labour cost with the lowest cost in the same city, industry and year. Let C_it be cash paid to and on behalf of employees, N_it the number of employees, c the city and j the industry. For positive C_it and N_it, q_it = ln(C_it/N_it); b_cjt = min[h∈(c,j,t)] q_ht; and Premium_it = q_it − b_cjt. Taking the minimum of log costs is equivalent to logging the minimum positive cost. The benchmark varies jointly across city, industry and year; it is not a city-wide or time-invariant minimum.

Table 5 uses yjwage and yjwage1 as distinct source relative labour-cost indices on their reported scales. The benchmark difference defines the economic premium concept, not a common numerical identity imposed on both fields. Both cover 17,438 firm-years. Their exact transformations from payroll records are not reconstructed by this replication.

B4. Employee protection

The source is the Employee Protection Key Indicators table in CSMAR’s Corporate Common Prosperity Research Database. The seven dimensions are lawful employment, production-safety investment, production-safety performance, occupational-health protection, the employee social-security contribution ratio, the commercial-insurance investment ratio and employee-rights protection. The construction uses the database’s standardised indicator values.

For indicator j, let u_aj be the non-negative standardised value for observation a in the weighting reference set Ω, with m observations. Entropy weighting uses p_aj = u_aj / Σ[a∈Ω]u_aj, e_j = −Σ[a∈Ω]p_aj ln(p_aj)/ln(m), d_j = 1−e_j, and α_j = d_j/Σ[k=1,…,7]d_k, with 0 ln 0 defined as 0. The weighted composite is Σ[j=1,…,7]α_j u_aj. An indicator constant or all-zero over Ω carries no information weight; m must exceed one and at least one informative dimension is required. Score applies these entropy weights; pScore applies principal components to the same seven dimensions and reports the resulting composite. Both series cover all 17,441 firm-years. Higher scores indicate stronger protection; regression coefficients are score-point changes.

The treatment indicator is a policy proxy for access to publicly financed preventive-health inputs. The theoretical investment input and health stock are distinct from observed city entry.
