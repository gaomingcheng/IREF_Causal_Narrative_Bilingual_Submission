"""Assemble the estimation panel from the distributed analytical exports."""
from pathlib import Path
import json, gzip, io
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parents[2]

def main():
    d = pd.read_stata(ROOT/'data/analysis_data.dta', convert_categoricals=False)
    d['stock_source'] = pd.to_numeric(d.Stkcd, errors='coerce')
    d['stock_source'] = d.stock_source.fillna(d.groupby('id').stock_source.transform('max'))
    d['year'] = d.year.astype(int)
    keys = ['id', 'year']
    for name in ['labour_share', 'labour_investment', 'workforce_structure', 'worker_expenditure']:
        x = pd.read_csv(ROOT/f'data/processed/{name}_panel.csv.gz')
        assert len(x) == 17441 and not x.duplicated(keys).any()
        if name == 'labour_share':
            d = d.merge(x[keys+['stock_code']].rename(columns={'stock_code':'stock'}), on=keys, validate='one_to_one')
        columns = [c for c in x if c not in keys+['stock_code','city_s','did','first_treat']]
        d = d.drop(columns=[c for c in columns if c in d])
        d = d.merge(x[keys+columns], on=keys, validate='one_to_one')
    d['industry_year'] = d.indus1.astype(str)+'_'+d.year.astype(str)
    d['province_year'] = d.prov.astype(str)+'_'+d.year.astype(str)
    for source,y in [('share','LS1'),('allocation','allocation_abs'),('structure','occupational_high_share'),('spending','log_union_education_w')]:
        d['observed_'+source] = d[y].notna().astype(float)
    d['common_outcomes'] = d[['LS1','allocation_abs','occupational_high_share','log_union_education_w']].notna().all(axis=1)
    base=d.loc[d.year.eq(2012),['id','spend_assets_bp_w','LS1']].rename(columns={'spend_assets_bp_w':'pre_spend','LS1':'pre_ls'})
    d=d.merge(base,on='id',how='left',validate='many_to_one')
    d['labor_efficiency']=d.allocation_abs
    d['over_hire']=d.over_component
    d['under_hire']=d.under_component
    d['StaffNumber']=d.staff_external
    linked_columns = [
        'size104','lev104','roa104','fa104','cash104','soe104','big4104',
        'TobinQ','Growth','Board','Indep','Dual','ListAge','Inst','Mshare','HHI',
    ]
    for c in linked_columns: d[c]=d[c].where(d.stock.notna())
    payload=d.to_csv(index=False).encode('utf-8')
    target=ROOT/'data/supplementary_panel.csv.gz'
    target.write_bytes(gzip.compress(payload,mtime=0))
    assert gzip.decompress(target.read_bytes())==payload
    assert len(pd.read_csv(io.BytesIO(payload),low_memory=False))==len(d)
    print('Estimation panel assembled from four processed exports.')
if __name__=='__main__':main()
