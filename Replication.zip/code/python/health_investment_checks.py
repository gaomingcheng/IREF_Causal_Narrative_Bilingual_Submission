"""Health-investment policy exposure: migration and cohort-comparison checks."""
from pathlib import Path
import importlib.util,json
import numpy as np,pandas as pd
from scipy.stats import norm,chi2
ROOT=Path(__file__).resolve().parents[2]
sp=importlib.util.spec_from_file_location("original",Path(__file__).with_name("run_full_analysis.py"))
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
def paired_gt(d,y,controls=None):
 """Paired two-period cohort-time DID with never-treated controls.
 Fixed observed treated-pair weights; joint city score aggregation for inference.
 This is a transparent unconditional DID implementation, not a full did package.
 """
 controls=controls or []
 a=d[list(dict.fromkeys(['id','year','city_s','first_treat',y]+controls))].dropna().copy()
 cities=np.sort(d.city_s.unique());citymap={c:i for i,c in enumerate(cities)}
 rows=[];influence=[]
 for g in [2013,2015,2016,2018]:
  b=a.loc[a.year.eq(g-1),['id',y]+controls].rename(columns={y:'base',**{k:'base_'+k for k in controls}})
  for t in sorted(a.year.unique()):
   if t==g-1:continue
   q=a.loc[a.year.eq(t)&a.first_treat.isin([0,g])].merge(b,on='id',validate='one_to_one')
   q['D']=q.first_treat.eq(g).astype(float)
   n1=int(q.D.sum());n0=len(q)-n1
   if min(n1,n0)<2:continue
   delta=q[y].to_numpy()-q.base
   if controls:
    # Outcome-regression DID: fit the untreated trend on never-treated firms only.
    # Allows heterogeneous treatment responses; requires a correct linear control trend.
    x=np.column_stack([np.ones(len(q)),q[['base_'+k for k in controls]].to_numpy()]);treated=q.D.eq(1).to_numpy()
    x0=x[~treated];inv=np.linalg.pinv(x0.T@x0);theta=inv@x0.T@delta[~treated];pred=x@theta
    tau=float(np.mean(delta[treated]-pred[treated]));score=np.zeros(len(q))
    score[treated]=(delta[treated]-pred[treated]-tau)/n1
    score[~treated]=-(x0@inv@x[treated].mean(axis=0))*(delta[~treated]-pred[~treated])
   else:
    x=np.column_stack([np.ones(len(q)),q.D]);inv=np.linalg.inv(x.T@x);beta=inv@x.T@delta;u=delta-x@beta
    tau=float(beta[1]);score=(x@inv[:,1])*u
   inf=np.zeros(len(cities));np.add.at(inf,q.city_s.map(citymap),score)
   se=np.sqrt(len(cities)/(len(cities)-1)*inf@inf)
   row=dict(outcome=y,cohort=g,year=int(t),event=int(t-g),coefficient=tau,std_error=float(se),observations=len(q),treated_pairs=n1,control_pairs=n0,treated_cities=q.loc[q.D.eq(1),'city_s'].nunique(),control_cities=q.loc[q.D.eq(0),'city_s'].nunique())
   rows.append(row);influence.append(inf)
 if not rows:return None
 cells=pd.DataFrame(rows);inf=np.vstack(influence)
 def aggregate(mask):
  ix=np.flatnonzero(mask);q=cells.iloc[ix];w=q.treated_pairs.to_numpy(float);w=w/w.sum()
  b=float(w@q.coefficient);z=w@inf[ix];se=float(np.sqrt(len(cities)/(len(cities)-1)*(z@z)))
  p=float(2*norm.sf(abs(b/se))) if se>0 else (1. if np.isclose(b,0) else 0.)
  return dict(outcome=y,coefficient=b,std_error=se,p_value=p,lower=b-1.96*se,upper=b+1.96*se,cells=len(q),treated_pair_weight=int(q.treated_pairs.sum())),z
 overall,overall_inf=aggregate(cells.event.ge(0).to_numpy())
 exclude,_=aggregate((cells.event.ge(0)&cells.cohort.ne(2015)).to_numpy());exclude['specification']='Exclude single-city 2015 cohort'
 events=[];preinf=[];prebeta=[]
 for k in sorted(cells.event.unique()):
  r,z=aggregate(cells.event.eq(k).to_numpy());r['event']=int(k);events.append(r)
  if k<0:preinf.append(z);prebeta.append(r['coefficient'])
 if preinf:
  v=np.vstack(preinf);cov=len(cities)/(len(cities)-1)*v@v.T;b=np.array(prebeta)
  rank=np.linalg.matrix_rank(cov);wald=float(b@np.linalg.pinv(cov)@b)
  overall['joint_pre_p']=float(chi2.sf(wald,rank)) if rank else (1. if np.allclose(b,0) else 0.);overall['joint_pre_df']=int(rank)
 return cells,overall,pd.DataFrame(events),exclude

def main():
 d=m.load_data();out=ROOT/"output/tables"
 movers=d.groupby("id").city_s.nunique();ids=movers[movers.gt(1)].index
 stable=d[~d.id.isin(ids)].copy()
 assert stable.groupby("id").first_treat.nunique().max()==1
 assert (stable.did.eq(1)==(stable.first_treat.gt(0)&stable.year.ge(stable.first_treat))).all()
 base=m.row_for(m.hdfe_reg(d,"pop",["did"],m.CONTROLS),"did","Original baseline")
 assert np.isclose(base["coefficient"],.04862059512150118,atol=1e-9)
 r=m.row_for(m.hdfe_reg(stable,"pop",["did"],m.CONTROLS),"did","Stable registered city")
 rows=[base,r]
 for controls,label in [(None,"Never-treated paired DID"),(m.CONTROLS,"Baseline-adjusted paired DID")]:
  cells,overall,event,ex=paired_gt(stable,"pop",controls)
  labelkey="adjusted" if controls else "unconditional"
  cells.to_csv(out/f"table_A10_cells_{labelkey}.csv",index=False)
  event.to_csv(out/f"table_A10_event_{labelkey}.csv",index=False)
  pd.DataFrame([ex]).to_csv(out/f"table_A10_exclude2015_{labelkey}.csv",index=False)
  overall["specification"]=label;overall["observations"]=len(stable);overall["clusters"]=stable.city_s.nunique()
  rows.append(overall)
 # Paired education comparison, retaining the original sample and test.
 pd.DataFrame(rows).to_csv(out/"table_A10_employment_identification.csv",index=False)
 audit={"baseline":base,"stable_firms":int(stable.id.nunique()),"stable_rows":len(stable),"stable_cities":int(stable.city_s.nunique()),"mover_firms":len(ids),"mover_rows":int(d.id.isin(ids).sum()),"original_employment_percent":float(np.expm1(base["coefficient"])*100)}
 audit["baseline"].pop("panel",None)
 assert np.isclose(np.log1p(audit["original_employment_percent"]/100),base["coefficient"])
 (ROOT/"output/logs/health_investment_identification.json").write_text(json.dumps(audit,indent=2))
 print(pd.DataFrame(rows).to_string(index=False),flush=True)
 print(json.dumps(audit,indent=2),flush=True)
if __name__=="__main__":main()
