"""Reproduce the health-capital and firm-employment results."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parents[2]
logs=root/'output/logs';logs.mkdir(parents=True,exist_ok=True)
steps=[('prepare_panel.py','panel_construction.txt'),('run_full_analysis.py','full_analysis_run.txt'),('subgroup_differences.py','subgroup_differences.txt'),('health_investment_checks.py','health_investment_checks.txt'),('check_health_framework.py','health_framework_checks.txt'),('pre2017_comparison.py','pre2017_comparison.txt')]
for script,log in steps:
    print('Running',script,flush=True)
    with (logs/log).open('w') as f:
        subprocess.run([sys.executable,str(root/'code/python'/script)],cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
print('Analysis complete.',flush=True)
