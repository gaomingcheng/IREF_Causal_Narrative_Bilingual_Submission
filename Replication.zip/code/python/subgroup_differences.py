from pathlib import Path
import numpy as np, pandas as pd
from scipy import sparse
from scipy.sparse.linalg import lsqr
from scipy.stats import norm
D=pd.read_stata('data/analysis_data.dta',convert_categoricals=False)
C=['size','nra','debt','fa','cash','share','property','audit']
def score(out, subset):
 df=D.loc[subset,[out,'did']+C+['id','indus1','year','city_s']].dropna()
 F=sparse.hstack([sparse.csr_matrix((np.ones(len(df)),(np.arange(len(df)),pd.factorize(df[v])[0])),shape=(len(df),df[v].nunique())) for v in ['id','indus1','year']],format='csr')
 X0=df[[out,'did']+C].to_numpy(float)
 R=np.column_stack([X0[:,j]-F@lsqr(F,X0[:,j],atol=1e-11,btol=1e-11)[0] for j in range(X0.shape[1])])
 y,X=R[:,0],R[:,1:];b=np.linalg.lstsq(X,y,rcond=None)[0];e=y-X@b
 inv=np.linalg.pinv(X.T@X)
 u=(X*e[:,None])@inv[0,:]
 s=pd.Series(u).groupby(df.city_s.reset_index(drop=True)).sum()
 return b[0],s,len(df),X.shape[1]
records=[]
for label,o1,s1,o0,s0 in [
 ('high vs low skill','highpop',D.highpop.notna(),'lowpop',D.lowpop.notna()),
 ('high vs low labor share','pop',D.d1==1,'pop',D.d1==0),
 ('labor scarce vs surplus','pop',D.d2==0,'pop',D.d2==1),
 ('state vs private','pop',D.property==1,'pop',D.property==0)]:
 b1,a,n1,k1=score(o1,s1);b0,c,n0,k0=score(o0,s0)
 G=len(set(a.index)|set(c.index));m=a.reindex(set(a.index)|set(c.index),fill_value=0)-c.reindex(set(a.index)|set(c.index),fill_value=0)
 se=np.sqrt(G/(G-1)*(m*m).sum())
 print(label,'b1',b1,'b0',b0,'difference',b1-b0,'se',se,'p',2*norm.sf(abs((b1-b0)/se)),'N',n1,n0)

 records.append({'comparison':label,'coefficient_1':b1,'coefficient_0':b0,'difference':b1-b0,'std_error':se,'p_value':2*norm.sf(abs((b1-b0)/se)),'n_1':n1,'n_0':n0})
pd.DataFrame(records).to_csv('output/tables/table_06b_subgroup_differences.csv',index=False)
