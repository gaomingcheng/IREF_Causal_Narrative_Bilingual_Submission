"""Check the stated health-stock and conditional hiring relations numerically."""
from pathlib import Path
import json,itertools
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
def optimal(g,alpha,p=1.2,a=1.1,k=3.,w=.8):
 h=1+.2*g;v=.3*np.exp(-.4*g)
 return (p*(1-alpha)*a*k**alpha*h**(1-alpha)/(w+v))**(1/alpha)
def run():
 errors=[];cases=0
 for alpha,g,w in itertools.product([.2,.5,.8],[0.,.5,1.,5.],[.01,.8,3.]):
  l=optimal(g,alpha,w=w);h=1+.2*g;v=.3*np.exp(-.4*g)
  marginal=1.2*(1-alpha)*1.1*3**alpha*h**(1-alpha)*l**(-alpha)
  assert np.isclose(marginal,w+v,rtol=1e-9)
  eps=1e-5
  derivative=(np.log(optimal(g+eps,alpha,w=w))-np.log(optimal(g-eps,alpha,w=w)))/(2*eps)
  analytical=((1-alpha)*.2/h+.4*v/(w+v))/alpha
  assert derivative>0 and np.isclose(derivative,analytical,rtol=1e-6,atol=1e-8)
  errors.append(abs(derivative-analytical));cases+=1
 # Health-stock preservation, including zero additions and zero initial stock.
 stock_cases=0
 for h,u,g0,g1 in itertools.product([0.,.5,1.],[0.,.1],[0.,1.],[2.,5.]):
  delta0=.02+.2*np.exp(-.3*g0);delta1=.02+.2*np.exp(-.3*g1)
  new0=(1-delta0)*h+u;new1=(1-delta1)*h+u
  assert 0<delta1<=delta0<1 and new1>=new0>=0
  stock_cases+=1
 out={'conditional_hiring_grid_cases':cases,'health_stock_boundary_cases':stock_cases,'max_derivative_error':max(errors),'scope':'Conditional model checks, not a calibration or estimate of latent health capital.'}
 (ROOT/'output/logs/health_framework_checks.json').write_text(json.dumps(out,indent=2))
 print(json.dumps(out,indent=2))
if __name__=='__main__':run()
