#!/usr/bin/env python3
"""Reproduce the 2011-2018 health human capital and employment analysis.

The script uses the estimation panel in data/analysis_data.dta. It implements
high-dimensional fixed-effect OLS by sparse residualisation, city-clustered
inference. Outputs are CSV and JSON files and publication-ready colour figures.
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import sparse
from scipy.sparse.linalg import lsqr
from scipy.stats import chi2, norm


SCRIPT = Path(__file__).resolve()
# In the distributed package this file lives at code/python/run_full_analysis.py.
PACKAGE_ROOT = SCRIPT.parents[2]
DATA = PACKAGE_ROOT / "data" / "analysis_data.dta"
OUT = PACKAGE_ROOT / "output"
TABLES = OUT / "tables"
FIGURES = OUT / "figures"
LOGS = OUT / "logs"
for folder in (TABLES, FIGURES, LOGS):
    folder.mkdir(parents=True, exist_ok=True)

CONTROLS = ["size", "nra", "debt", "fa", "cash", "share", "property", "audit"]
EVENT_VARS = ["pre4", "pre3", "pre2", "post0", "post1", "post2", "post3", "post4"]
EVENT_LABELS = ["Pre <= -4", "Pre -3", "Pre -2", "Post 0", "Post +1", "Post +2", "Post +3", "Post >= +4"]
PALETTE = {
    "red": "#9E1B32",
    "blue": "#2A6FBB",
    "teal": "#238B8D",
    "gold": "#D99B2B",
    "green": "#3A8E5B",
    "navy": "#263A5B",
    "grey": "#6B7280",
    "light": "#E8EDF3",
}


def load_data() -> pd.DataFrame:
    panel_path = PACKAGE_ROOT / 'data' / 'supplementary_panel.csv.gz'
    if not panel_path.exists():
        raise FileNotFoundError('Run code/python/run_all.py first to build data/supplementary_panel.csv.gz.')
    data = pd.read_csv(panel_path, low_memory=False)
    assert len(data) == 17441
    assert sorted(data["year"].unique().tolist()) == [2011.0, 2012.0, 2013.0, 2014.0, 2015.0, 2016.0, 2017.0, 2018.0]
    assert not data.duplicated(["id", "year"]).any()
    assert data["id"].nunique() == 2214
    assert data["city_s"].nunique() == 249
    assert data.groupby(["city_s", "year"])["did"].nunique().max() == 1
    return data


def fe_matrix(df: pd.DataFrame, fixed_effects: list[str], slopes: list[tuple[str, str]] | None = None) -> sparse.csr_matrix:
    mats: list[sparse.csr_matrix] = []
    n = len(df)
    rows = np.arange(n)
    for col in fixed_effects:
        codes, names = pd.factorize(df[col], sort=True)
        mats.append(sparse.coo_matrix((np.ones(n), (rows, codes)), shape=(n, len(names))).tocsr())
    for group_col, value_col in slopes or []:
        codes, names = pd.factorize(df[group_col], sort=True)
        value = df[value_col].to_numpy(float)
        mats.append(sparse.coo_matrix((value, (rows, codes)), shape=(n, len(names))).tocsr())
    return sparse.hstack(mats, format="csr")


def residualize(matrix: np.ndarray, df: pd.DataFrame, fixed_effects: list[str], slopes: list[tuple[str, str]] | None = None) -> np.ndarray:
    fmat = fe_matrix(df, fixed_effects, slopes)
    out = []
    for j in range(matrix.shape[1]):
        fitted = fmat @ lsqr(fmat, matrix[:, j], atol=1e-11, btol=1e-11, iter_lim=1200)[0]
        out.append(matrix[:, j] - fitted)
    return np.column_stack(out)


def hdfe_reg(
    data: pd.DataFrame,
    outcome: str,
    rhs: list[str],
    controls: list[str] | None = None,
    subset: pd.Series | np.ndarray | None = None,
    fixed_effects: list[str] | None = None,
    slopes: list[tuple[str, str]] | None = None,
    cluster: str = "city_s",
) -> dict:
    controls = controls or []
    fixed_effects = fixed_effects or ["id", "indus1", "year"]
    base = data if subset is None else data.loc[subset]
    cols = list(dict.fromkeys([outcome] + rhs + controls + fixed_effects + [cluster] + [x for pair in (slopes or []) for x in pair]))
    df = base[cols].dropna().copy()
    names = rhs + controls
    raw = df[[outcome] + names].to_numpy(float)
    res = residualize(raw, df, fixed_effects, slopes)
    y = res[:, 0]
    x = res[:, 1:]
    beta = np.linalg.lstsq(x, y, rcond=None)[0]
    err = y - x @ beta
    cluster_values = df[cluster].to_numpy()
    clusters, group = np.unique(cluster_values, return_inverse=True)
    scores = np.zeros((len(clusters), x.shape[1]))
    np.add.at(scores, group, x * err[:, None])
    xtx_inv = np.linalg.pinv(x.T @ x)
    g = len(clusters)
    n = len(df)
    k = x.shape[1]
    correction = g / (g - 1) * (n - 1) / (n - k)
    cov = xtx_inv @ scores.T @ scores @ xtx_inv * correction
    se = np.sqrt(np.clip(np.diag(cov), 0, None))
    tstat = np.divide(beta, se, out=np.full_like(beta, np.nan), where=se > 0)
    pval = 2 * norm.sf(np.abs(tstat))
    sse = float(err @ err)
    sst = float(y @ y)
    within_r2 = 1 - sse / sst
    adj_within_r2 = 1 - (1 - within_r2) * (n - 1) / max(n - k, 1)
    return {
        "df": df,
        "names": names,
        "beta": beta,
        "se": se,
        "t": tstat,
        "p": pval,
        "cov": cov,
        "n": n,
        "clusters": g,
        "adj_within_r2": adj_within_r2,
        "fixed_effects": fixed_effects,
        "cluster": cluster,
    }


def row_for(result: dict, variable: str, specification: str, panel: str = "") -> dict:
    idx = result["names"].index(variable)
    return {
        "panel": panel,
        "specification": specification,
        "variable": variable,
        "coefficient": float(result["beta"][idx]),
        "std_error": float(result["se"][idx]),
        "t_stat": float(result["t"][idx]),
        "p_value": float(result["p"][idx]),
        "observations": int(result["n"]),
        "clusters": int(result["clusters"]),
        "adj_within_r2": float(result["adj_within_r2"]),
    }


def add_event_variables(data: pd.DataFrame) -> pd.DataFrame:
    d = data.copy()
    event_time = d["year"] - d["first_treat"]
    treated = d["treat"].eq(1)
    conditions = {
        "pre4": event_time.le(-4),
        "pre3": event_time.eq(-3),
        "pre2": event_time.eq(-2),
        "post0": event_time.eq(0),
        "post1": event_time.eq(1),
        "post2": event_time.eq(2),
        "post3": event_time.eq(3),
        "post4": event_time.ge(4),
    }
    for name, cond in conditions.items():
        d[name] = (treated & cond).astype(float)
    return d


def significance(p: float) -> str:
    if p < 0.01:
        return "***"
    if p < 0.05:
        return "**"
    if p < 0.10:
        return "*"
    return ""


def descriptive_table(data: pd.DataFrame) -> pd.DataFrame:
    variables = ["pop", "did"] + CONTROLS
    labels = {
        "pop": "Employment (log employees)",
        "did": "Preventive health investment exposure",
        "size": "Firm size",
        "nra": "Return on assets",
        "debt": "Debt-equity ratio",
        "fa": "Fixed-asset ratio",
        "cash": "Operating cash flow",
        "share": "Ownership balance",
        "property": "State-owned enterprise",
        "audit": "Big Four auditor",
        "labor_efficiency": "Labour-allocation inefficiency",
        "Labor2": "Employee change rate",
    }
    rows = []
    for var in variables:
        x = data[var].dropna().astype(float)
        rows.append({
            "variable": var,
            "label": labels[var],
            "N": int(x.size),
            "mean": float(x.mean()),
            "sd": float(x.std(ddof=1)),
            "min": float(x.min()),
            "max": float(x.max()),
        })
    return pd.DataFrame(rows)


def baseline_and_event(data: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict, dict]:
    no_controls = hdfe_reg(data, "pop", ["did"], [])
    with_controls = hdfe_reg(data, "pop", ["did"], CONTROLS)
    base_rows = []
    for spec, result in [("(1) No controls", no_controls), ("(2) Baseline controls", with_controls)]:
        for name in result["names"]:
            base_rows.append(row_for(result, name, spec))
    base = pd.DataFrame(base_rows)

    d = add_event_variables(data)
    ev1 = hdfe_reg(d, "pop", EVENT_VARS, [])
    ev2 = hdfe_reg(d, "pop", EVENT_VARS, CONTROLS)
    event_rows = []
    for spec, result in [("(1) No controls", ev1), ("(2) Baseline controls", ev2)]:
        for var, label in zip(EVENT_VARS, EVENT_LABELS):
            row = row_for(result, var, spec)
            row["event_label"] = label
            event_rows.append(row)
        wald = result["beta"][:3] @ np.linalg.pinv(result["cov"][:3, :3]) @ result["beta"][:3]
        p_joint = float(chi2.sf(wald, 3))
        event_rows[-1]["pretrend_joint_p"] = p_joint
    return base, pd.DataFrame(event_rows), with_controls, ev2


def alternating_demean(matrix: np.ndarray, groups: list[np.ndarray], tol: float = 1e-10, max_iter: int = 200) -> np.ndarray:
    res = matrix.astype(float, copy=True)
    for _ in range(max_iter):
        before = res.copy()
        for codes in groups:
            n_groups = int(codes.max()) + 1
            sums = np.zeros((n_groups, res.shape[1]))
            np.add.at(sums, codes, res)
            counts = np.bincount(codes, minlength=n_groups).astype(float)
            res -= sums[codes] / counts[codes, None]
        scale = max(float(np.max(np.abs(before))), 1.0)
        if float(np.max(np.abs(res - before))) / scale < tol:
            break
    return res


def robustness(data: pd.DataFrame) -> pd.DataFrame:
    rows = []

    baseline = hdfe_reg(data, "pop", ["did"], CONTROLS)
    rows.append(row_for(baseline, "did", "Baseline", "A. Fixed effects and inference"))
    firm_cluster = hdfe_reg(data, "pop", ["did"], CONTROLS, cluster="id")
    rows.append(row_for(firm_cluster, "did", "Firm-clustered inference", "A. Fixed effects and inference"))
    province_year = hdfe_reg(data, "pop", ["did"], CONTROLS, fixed_effects=["id", "indus1", "prov_year"])
    rows.append(row_for(province_year, "did", "Province-by-year fixed effects", "A. Fixed effects and inference"))

    policy_specs = [
        ("VAT credit-refund control", "survatdid"),
        ("VAT reform control", "vatchange"),
        ("Accelerated-depreciation control", "acdep"),
        ("Unemployment-insurance control", "lunemp"),
    ]
    for label, policy in policy_specs:
        result = hdfe_reg(data, "pop", ["did", policy], CONTROLS)
        rows.append(row_for(result, "did", label, "B. Concurrent policies"))

    sample_specs = [
        ("Exclude one pooling regime", data["tcprov1"].eq(0)),
        ("Exclude alternative pooling regime", data["tcprov2"].eq(0)),
        ("Exclude population-outflow cities", data["flow"].eq(1)),
        ("Exclude no-accident cities", data["safecity_s"].eq(1)),
        ("Restrict city economic size", data["strong"].eq(1)),
        ("First formal-pilot definition", data["choose"].eq(0)),
        ("Exclude exploratory-pilot cities", data["qw"].eq(1)),
        ("Exclude industry switchers", data["changed_3"].eq(0)),
    ]
    for label, subset in sample_specs:
        fixed_effects = ["id", "year"] if label == "Exclude industry switchers" else ["id", "indus1", "year"]
        result = hdfe_reg(data, "pop", ["did"], CONTROLS, subset=subset, fixed_effects=fixed_effects)
        rows.append(row_for(result, "did", label, "C. Sample definitions"))

    for label, lead in [("One-year anticipation", "before1"), ("Two-year anticipation", "before2")]:
        result = hdfe_reg(data, "pop", [lead, "did"], CONTROLS)
        did_row = row_for(result, "did", label, "D. Anticipation")
        did_row["lead_variable"] = lead
        lead_row = row_for(result, lead, label, "D. Anticipation")
        did_row["lead_coefficient"] = lead_row["coefficient"]
        did_row["lead_std_error"] = lead_row["std_error"]
        did_row["lead_p_value"] = lead_row["p_value"]
        rows.append(did_row)

    for cohort in [2013, 2015, 2016, 2018]:
        subset = ~data["first_treat"].eq(cohort)
        result = hdfe_reg(data, "pop", ["did"], CONTROLS, subset=subset)
        rows.append(row_for(result, "did", f"Exclude {cohort} cohort", "E1. Cohort-exclusion diagnostics"))

    return pd.DataFrame(rows)


def mechanism_heterogeneity(data: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    mechanism_defs = [
        ("Annual-report risk index (six terms)", "risk1"),
        ("Annual-report risk index (three terms)", "risk2"),
        ("Annual-report risk index (risk word only)", "risk3"),
        ("Negative financial Z-score", "fZscore"),
        ("Relative labour cost", "yjwage"),
        ("Alternative relative labour cost", "yjwage1"),
        ("Employee-protection score", "Score"),
        ("Employee-protection score (PCA)", "pScore"),
    ]
    mrows = []
    for label, outcome in mechanism_defs:
        result = hdfe_reg(data, outcome, ["did"], CONTROLS)
        row = row_for(result, "did", label)
        row["outcome"] = outcome
        mrows.append(row)

    hetero_specs = [
        ("High-skill employment", "highpop", data["highpop"].notna()),
        ("Lower-skill employment", "lowpop", data["lowpop"].notna()),
        ("High labour-income-share firms", "pop", data["d1"].eq(1)),
        ("Low labour-income-share firms", "pop", data["d1"].eq(0)),
        ("Labour-surplus firms", "pop", data["d2"].eq(1)),
        ("Labour-scarce firms", "pop", data["d2"].eq(0)),
        ("State-owned enterprises", "pop", data["property"].eq(1)),
        ("Non-state-owned enterprises", "pop", data["property"].eq(0)),
    ]
    hrows = []
    for label, outcome, subset in hetero_specs:
        result = hdfe_reg(data, outcome, ["did"], CONTROLS, subset=subset)
        row = row_for(result, "did", label)
        row["outcome"] = outcome
        hrows.append(row)

    return pd.DataFrame(mrows), pd.DataFrame(hrows)


def balance_table(data: pd.DataFrame) -> pd.DataFrame:
    pre = data[data["year"].eq(2011)].copy()
    pre["ever_treated"] = pre["first_treat"].gt(0)
    rows = []
    labels = {
        "size": "Firm size", "nra": "Return on assets", "debt": "Debt-equity ratio",
        "fa": "Fixed-asset ratio", "cash": "Operating cash flow", "share": "Ownership balance",
        "property": "State ownership", "audit": "Big Four auditor",
    }
    for var in CONTROLS:
        treated = pre.loc[pre["ever_treated"], var].dropna().astype(float)
        control = pre.loc[~pre["ever_treated"], var].dropna().astype(float)
        pooled = math.sqrt((treated.var(ddof=1) + control.var(ddof=1)) / 2)
        smd = (treated.mean() - control.mean()) / pooled if pooled else 0.0
        rows.append({
            "variable": var,
            "label": labels[var],
            "treated_mean": float(treated.mean()),
            "never_treated_mean": float(control.mean()),
            "standardized_difference": float(smd),
            "treated_n": int(treated.size),
            "never_treated_n": int(control.size),
        })
    return pd.DataFrame(rows)


def save_figure(fig: plt.Figure, stem: str) -> None:
    fig.savefig(FIGURES / f"{stem}.png", dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(FIGURES / f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    fig.savefig(FIGURES / f"{stem}.tiff", dpi=600, bbox_inches="tight", facecolor="white", pil_kwargs={"compression":"tiff_lzw"})
    plt.close(fig)


def make_figures(
    data: pd.DataFrame,
    event: pd.DataFrame,
    robust: pd.DataFrame,
    balance: pd.DataFrame,
    mechanism: pd.DataFrame,
    heterogeneity: pd.DataFrame,
) -> None:
    sns.set_theme(style="whitegrid", font="DejaVu Sans")
    plt.rcParams.update({"axes.titlesize": 13, "axes.labelsize": 11, "xtick.labelsize": 9.5, "ytick.labelsize": 9.5})

    # Figure 1: controlled TWFE event-time estimates.
    main = event[event["specification"].eq("(2) Baseline controls")].copy()
    event_x = np.array([-4, -3, -2, 0, 1, 2, 3, 4], dtype=float)
    fig, ax = plt.subplots(figsize=(9.34375, 5.708))
    ax.axhline(0, color="#333333", lw=1)
    ax.axvline(-0.5, color=PALETTE["grey"], lw=1, ls="--")
    ax.errorbar(event_x, main["coefficient"], yerr=1.96 * main["std_error"], fmt="o-", color=PALETTE["red"], ecolor=PALETTE["red"], capsize=3, lw=1.8, label="TWFE event study")
    ax.set_xticks(event_x, ["<=-4", "-3", "-2", "0", "+1", "+2", "+3", ">=+4"])
    ax.set_xlabel("Years relative to pilot entry (-1 omitted)")
    ax.set_ylabel("Estimated effect on log employment")
    ax.set_title("Employment response around pilot entry", loc="left", fontweight="bold")
    ax.set_ylim(-0.15, 0.20)
    ax.legend(frameon=False, loc="upper left")
    save_figure(fig, "figure_01_event_study")

    # Figure 3: coefficient plot for the pre-specified heterogeneity splits.
    h = heterogeneity.copy()
    h_order = [
        "Lower-skill employment", "High-skill employment",
        "Low labour-income-share firms", "High labour-income-share firms",
        "Labour-surplus firms", "Labour-scarce firms",
        "Non-state-owned enterprises", "State-owned enterprises",
    ]
    h = h[h["specification"].isin(h_order)].copy()
    h["specification"] = pd.Categorical(h["specification"], categories=h_order, ordered=True)
    h = h.sort_values("specification").reset_index(drop=True)
    h["ci_low_plot"] = h["coefficient"] - 1.96 * h["std_error"]
    h["ci_high_plot"] = h["coefficient"] + 1.96 * h["std_error"]
    fig, ax = plt.subplots(figsize=(8.2, 5.5))
    y = np.arange(len(h))
    colors = [PALETTE["red"] if "High" in s or "Scarce" in s or "State-owned" in s else PALETTE["blue"] for s in h["specification"].astype(str)]
    ax.hlines(y, h["ci_low_plot"], h["ci_high_plot"], color=colors, lw=1.8)
    ax.scatter(h["coefficient"], y, color=colors, s=42, zorder=3)
    ax.axvline(0, color="#333333", lw=1)
    ax.set_yticks(y, h["specification"])
    ax.set_xlabel("Estimated effect on log employment (95% interval)")
    ax.set_title("Heterogeneous employment effects", loc="left", fontweight="bold")
    sns.despine(ax=ax)
    save_figure(fig, "figure_02_heterogeneity")

    # Appendix figure: robustness coefficient plot excluding non-comparable RI SD row.
    plot = robust.copy()
    selected = plot[plot["specification"].isin([
        "Baseline", "Province-by-year fixed effects", "Firm-clustered inference",
        "Unemployment-insurance control", "Exclude population-outflow cities", "First formal-pilot definition",
        "Exclude exploratory-pilot cities", "Exclude industry switchers",
        "Exclude 2013 cohort", "Exclude 2015 cohort", "Exclude 2016 cohort", "Exclude 2018 cohort",
    ])].copy()
    selected["ci_low_plot"] = selected["coefficient"] - 1.96 * selected["std_error"]
    selected["ci_high_plot"] = selected["coefficient"] + 1.96 * selected["std_error"]
    selected = selected.iloc[::-1].reset_index(drop=True)
    fig, ax = plt.subplots(figsize=(8.2, 7.2))
    y = np.arange(len(selected))
    colors = [PALETTE["red"] if s == "Baseline" else PALETTE["blue"] for s in selected["specification"]]
    ax.hlines(y, selected["ci_low_plot"], selected["ci_high_plot"], color=colors, lw=1.8)
    ax.scatter(selected["coefficient"], y, color=colors, s=38, zorder=3)
    ax.axvline(0, color="#333333", lw=1)
    ax.set_yticks(y, selected["specification"])
    ax.set_xlabel("Estimated effect on log employment (95% interval)")
    ax.set_title("Sensitivity of the employment estimate", loc="left", fontweight="bold")
    sns.despine(ax=ax)
    save_figure(fig, "figure_A2_robustness_forest")

    # Appendix figure: 2011 balance plot.
    b = balance.sort_values("standardized_difference").reset_index(drop=True)
    fig, ax = plt.subplots(figsize=(7.6, 4.9))
    y = np.arange(len(b))
    ax.axvline(0, color="#333333", lw=1)
    ax.axvline(-0.1, color=PALETTE["grey"], lw=1, ls="--")
    ax.axvline(0.1, color=PALETTE["grey"], lw=1, ls="--")
    ax.scatter(b["standardized_difference"], y, color=PALETTE["teal"], s=42)
    ax.set_yticks(y, b["label"])
    ax.set_xlabel("Standardized mean difference in 2011")
    ax.set_title("Pre-treatment covariate balance", loc="left", fontweight="bold")
    sns.despine(ax=ax)
    save_figure(fig, "figure_A1_covariate_balance")





def output_and_unit_cost(data: pd.DataFrame) -> pd.DataFrame:
    """Revenue regressions (Table 7)."""
    work = data.copy()
    rows = []
    for outcome, label in [("re", "Log revenue")]:
        for cluster in ["city_s", "id"]:
            result = hdfe_reg(work, outcome, ["did"], CONTROLS, cluster=cluster)
            row = row_for(result, "did", label, "")
            row["cluster"] = "City" if cluster == "city_s" else "Firm"
            rows.append(row)
    return pd.DataFrame(rows)


def main() -> None:
    # Keep the output directory deterministic when the script is rerun.
    for old in FIGURES.glob("figure_*"):
        if old.is_file():
            old.unlink()
    for stale in [
        "table_04a_cohort_period_did.csv",
        "table_04b_cohort_dynamic.csv",
        "table_04b_cohort_dynamic_cells.csv",
    ]:
        path = TABLES / stale
        if path.exists():
            path.unlink()
    data = load_data()
    descriptive_table(data).to_csv(TABLES / "table_01_descriptive.csv", index=False)
    baseline, event, baseline_result, event_result = baseline_and_event(data)
    baseline.to_csv(TABLES / "table_02_baseline_full.csv", index=False)
    event.to_csv(TABLES / "table_03_event_study.csv", index=False)

    robust = robustness(data)
    robust.to_csv(TABLES / "table_04_robustness_merged.csv", index=False)

    mechanism, heterogeneity = mechanism_heterogeneity(data)
    mechanism.to_csv(TABLES / "table_05_mechanisms.csv", index=False)
    heterogeneity.to_csv(TABLES / "table_06_heterogeneity.csv", index=False)
    output_and_unit_cost(data).to_csv(TABLES / "table_07_revenue.csv", index=False)
    balance = balance_table(data)
    balance.to_csv(TABLES / "table_A1_covariate_balance.csv", index=False)

    make_figures(data, event, robust, balance, mechanism, heterogeneity)

    pretrend = event[event["specification"].eq("(2) Baseline controls")]["pretrend_joint_p"].dropna().iloc[0]
    print(json.dumps({
        "baseline": float(baseline_result["beta"][0]),
        "baseline_se": float(baseline_result["se"][0]),
        "pretrend_p": float(pretrend),
    }, indent=2))


if __name__ == "__main__":
    main()
