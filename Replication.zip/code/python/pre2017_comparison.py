"""Reproduce Appendix Table A12 using the original regression specification."""
from pathlib import Path
import importlib.util
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('analysis',Path(__file__).with_name('run_full_analysis.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
d=m.load_data()
moving=d.groupby('id').city_s.nunique().loc[lambda x:x.gt(1)].index
rows=[]
for name,frame in [
 ('Through 2016',d.loc[d.year.le(2016)]),
 ('Through 2016, stable city',d.loc[d.year.le(2016)&~d.id.isin(moving)])
]:
 rows.append(m.row_for(m.hdfe_reg(frame,'pop',['did'],m.CONTROLS),'did',name))
out=pd.DataFrame(rows)
assert int(out.iloc[0].observations)==13050
assert abs(out.iloc[0].coefficient-0.040789)<0.000001
out.to_csv(ROOT/'output/tables/table_A12_window.csv',index=False)
print(out.to_string(index=False))
