#!/usr/bin/env python3
"""Build the 2011–2018 estimation panel from the two panel components."""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT/'data'

def main():
    baseline = pd.read_stata(DATA/'analysis_data_2012_2018.dta', convert_categoricals=False)
    extension = pd.read_stata(DATA/'extension_2011.dta', convert_categoricals=False)
    assert sorted(baseline.year.unique()) == list(range(2012,2019))
    assert len(extension) == 2048 and extension.year.eq(2011).all()
    assert extension.did.eq(0).all()
    assert set(baseline.columns) == set(extension.columns)
    assert baseline.groupby('city_s').first_treat.nunique().max() == 1
    city_timing = baseline.groupby('city_s').first_treat.first()
    assert extension.city_s.isin(city_timing.index).all()
    # Match the derived timing variables to the existing formal-pilot definition.
    extension['first_treat'] = extension.city_s.map(city_timing).astype(baseline.first_treat.dtype)
    extension['policy'] = (extension.year-extension.first_treat).where(extension.first_treat.gt(0)).astype(baseline.policy.dtype)
    assert extension.treat.eq(extension.first_treat.gt(0).astype(float)).all()
    combined = pd.concat([baseline,extension[baseline.columns]],ignore_index=True).sort_values(['id','year']).reset_index(drop=True)
    assert len(combined) == 17441
    assert not combined.duplicated(['id','year']).any()
    assert combined.id.nunique() == 2214 and combined.city_s.nunique() == 249
    assert combined.groupby('city_s').first_treat.nunique().max() == 1
    assert combined.did.eq((combined.first_treat.gt(0)&combined.year.ge(combined.first_treat)).astype(float)).all()
    pd.testing.assert_frame_equal(
        baseline.sort_values(['id','year']).reset_index(drop=True),
        combined.loc[combined.year.ge(2012)].reset_index(drop=True),check_exact=True,
    )
    combined.to_stata(DATA/'analysis_data.dta',write_index=False,version=118)
    reopened = pd.read_stata(DATA/'analysis_data.dta',convert_categoricals=False)
    pd.testing.assert_frame_equal(combined,reopened,check_exact=True)
    print(f'Added {len(extension)} observations for 2011; {len(combined)} observations in 2011–2018.')

if __name__ == '__main__':
    main()
